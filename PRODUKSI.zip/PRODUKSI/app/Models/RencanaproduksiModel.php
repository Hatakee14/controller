<?php

namespace App\Models;

use CodeIgniter\Model;

class RencanaproduksiModel extends Model
{
    protected $table            = 'rencanaproduksi';
    protected $primaryKey       = 'IDRencanaProduksi';
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'IDRencanaProduksi',
        'TanggalRencana',
        'IDBahanBaku',
        'nama_produk',
        'JumlahRencana'];

}
