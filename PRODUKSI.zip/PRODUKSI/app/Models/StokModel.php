<?php

namespace App\Models;

use CodeIgniter\Model;

class StokModel extends Model
{
    protected $table            = 'bahanbaku';
    protected $primaryKey       = 'IDBahanBaku';
    protected $returnType       = 'array';
    protected $allowedFields    = ['IDBahanBaku','NamaBahanBaku','HargaPerUnit', 'JumlahStok'];
 

   
}
