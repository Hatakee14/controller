<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Produksi::index');
$routes->get('tambah', 'Produksi::tambah');
$routes->post('simpan_produksi', 'Produksi::simpan');
$routes->post('update_produksi', 'Produksi::update');
$routes->get('hapus/(:any)', 'produksi::hapus/$1');
